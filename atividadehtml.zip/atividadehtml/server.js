const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/teste.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'teste.html'));
});

app.get('/projeto.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'projeto.html'));
});

app.get('/animacao.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'animacao.html'));
});

app.listen(80, () => {
  console.log('Servidor rodando na porta 80!');
});